// Written by Jürgen Moßgraber - mossgrabers.de
// (c) 2017-2026
// Licensed under LGPLv3 - http://www.gnu.org/licenses/lgpl-3.0.txt

package de.mossgrabers.bitwig.framework.daw;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import com.bitwig.extension.controller.api.Application;
import com.bitwig.extension.controller.api.Arranger;
import com.bitwig.extension.controller.api.BooleanValue;
import com.bitwig.extension.controller.api.ControllerHost;
import com.bitwig.extension.controller.api.CursorDeviceFollowMode;
import com.bitwig.extension.controller.api.CursorDeviceLayer;
import com.bitwig.extension.controller.api.CursorTrack;
import com.bitwig.extension.controller.api.Device;
import com.bitwig.extension.controller.api.DeviceBank;
import com.bitwig.extension.controller.api.DeviceMatcher;
import com.bitwig.extension.controller.api.InsertionPoint;
import com.bitwig.extension.controller.api.LastClickedParameter;
import com.bitwig.extension.controller.api.MasterTrack;
import com.bitwig.extension.controller.api.PinnableCursorDevice;
import com.bitwig.extension.controller.api.Project;
import com.bitwig.extension.controller.api.SceneBank;
import com.bitwig.extension.controller.api.Track;
import com.bitwig.extension.controller.api.TrackBank;

import de.mossgrabers.bitwig.framework.daw.data.CursorDeviceImpl;
import de.mossgrabers.bitwig.framework.daw.data.CursorLayerImpl;
import de.mossgrabers.bitwig.framework.daw.data.CursorTrackImpl;
import de.mossgrabers.bitwig.framework.daw.data.DrumDeviceImpl;
import de.mossgrabers.bitwig.framework.daw.data.EqualizerDeviceImpl;
import de.mossgrabers.bitwig.framework.daw.data.FocusedParameterImpl;
import de.mossgrabers.bitwig.framework.daw.data.KompleteDevice;
import de.mossgrabers.bitwig.framework.daw.data.MasterTrackImpl;
import de.mossgrabers.bitwig.framework.daw.data.SpecificDeviceImpl;
import de.mossgrabers.bitwig.framework.daw.data.bank.DeviceBankImpl;
import de.mossgrabers.bitwig.framework.daw.data.bank.EffectTrackBankImpl;
import de.mossgrabers.bitwig.framework.daw.data.bank.MarkerBankImpl;
import de.mossgrabers.bitwig.framework.daw.data.bank.SlotBankImpl;
import de.mossgrabers.bitwig.framework.daw.data.bank.TrackBankImpl;
import de.mossgrabers.framework.daw.AbstractModel;
import de.mossgrabers.framework.daw.DataSetup;
import de.mossgrabers.framework.daw.ModelSetup;
import de.mossgrabers.framework.daw.clip.INoteClip;
import de.mossgrabers.framework.daw.constants.DeviceChainOperation;
import de.mossgrabers.framework.daw.constants.DeviceID;
import de.mossgrabers.framework.daw.data.ICursorTrack;
import de.mossgrabers.framework.daw.data.ISlot;
import de.mossgrabers.framework.daw.data.ISpecificDevice;
import de.mossgrabers.framework.daw.data.ITrack;
import de.mossgrabers.framework.daw.data.bank.IDeviceBank;
import de.mossgrabers.framework.daw.data.bank.ISceneBank;
import de.mossgrabers.framework.daw.data.bank.ISlotBank;
import de.mossgrabers.framework.daw.data.bank.ITrackBank;
import de.mossgrabers.framework.parameter.IFocusedParameter;
import de.mossgrabers.framework.scale.Scales;
import de.mossgrabers.framework.utils.FrameworkException;


/**
 * The model which contains all data and access to the DAW.
 *
 * @author Jürgen Moßgraber
 */
public class ModelImpl extends AbstractModel
{
    /** The UUID of the Drum Device. */
    public static final UUID               INSTRUMENT_DRUM_MACHINE = UUID.fromString ("8ea97e45-0255-40fd-bc7e-94419741e9d1");

    /** The number of tracks of an additional track bank which get a device bank. */
    private static final int               NUM_ADDITIONAL_DEVICE_TRACKS = 32;


    /**
     * The Bitwig track and device bank of a track as well as the device bank wrapper.
     *
     * @param track The Bitwig track
     * @param bwDeviceBank The Bitwig device bank
     * @param deviceBank The device bank
     */
    private record TrackDevices (Track track, DeviceBank bwDeviceBank, IDeviceBank deviceBank)
    {
        // Intentionally empty
    }


    private final ControllerHost           controllerHost;
    private final CursorTrack              bwCursorTrack;
    private final Track                    rootTrackGroup;
    private final BooleanValue             masterTrackEqualsValue;
    private final Map<Integer, ISceneBank> sceneBanks              = HashMap.newHashMap (1);
    private final Map<Integer, ISlotBank>  slotBanks               = HashMap.newHashMap (1);
    private final Map<Integer, ITrackBank> additionalTrackBanks    = HashMap.newHashMap (1);
    private final Map<Integer, ITrackBank> additionalSendBanks     = HashMap.newHashMap (1);
    /** The Bitwig objects and device banks of the tracks which have device banks. */
    private final Map<ITrack, TrackDevices> trackDevices            = new IdentityHashMap<> ();
    private IDeviceBank []                 trackDeviceBanks        = new IDeviceBank [0];
    private final SceneBank                sceneBank;
    private FocusedParameterImpl           focusedParameter        = null;


    /**
     * Constructor.
     *
     * @param modelSetup The configuration parameters for the model
     * @param dataSetup Some setup variables
     * @param controllerHost The controller host
     * @param scales The scales object
     */
    public ModelImpl (final ModelSetup modelSetup, final DataSetup dataSetup, final ControllerHost controllerHost, final Scales scales)
    {
        super (modelSetup, dataSetup, scales);

        this.controllerHost = controllerHost;

        final int numParamPages = this.modelSetup.getNumParamPages ();
        final int numParams = this.modelSetup.getNumParams ();

        final Application bwApplication = controllerHost.createApplication ();
        final Arranger bwArranger = controllerHost.createArranger ();

        this.application = new ApplicationImpl (bwApplication, bwArranger, this.valueChanger);
        final Project proj = controllerHost.getProject ();
        this.rootTrackGroup = proj.getRootTrackGroup ();
        this.project = new ProjectImpl (this.host, this.valueChanger, proj, bwApplication, numParamPages, numParams);

        this.transport = new TransportImpl (controllerHost, this.application, bwArranger, this.valueChanger);
        this.arranger = new ArrangerImpl (bwArranger);
        final int numMarkers = modelSetup.getNumMarkers ();
        if (numMarkers > 0)
            this.markerBank = new MarkerBankImpl (this.host, this.valueChanger, bwArranger, numMarkers, this.transport);

        this.mixer = new MixerImpl (controllerHost.createMixer ());
        this.groove = new GrooveImpl (controllerHost, this.valueChanger);

        final int numSends = this.modelSetup.getNumSends ();
        final int numScenes = this.modelSetup.getNumScenes ();

        // ----------------------------------------------------------------
        // Create track banks

        final TrackBank tb;
        this.bwCursorTrack = controllerHost.createCursorTrack ("MyCursorTrackID", "The Cursor Track", numSends, numScenes, true);
        final int numTracks = this.modelSetup.getNumTracks ();
        if (this.modelSetup.hasFlatTrackList ())
        {
            if (this.modelSetup.hasFullFlatTrackList ())
                tb = controllerHost.createTrackBank (numTracks, numSends, numScenes, true);
            else
                tb = controllerHost.createMainTrackBank (numTracks, numSends, numScenes);
            tb.followCursorTrack (this.bwCursorTrack);
        }
        else
            tb = this.bwCursorTrack.createSiblingsTrackBank (numTracks, numSends, numScenes, false, false);

        this.sceneBank = numScenes > 0 ? tb.sceneBank () : null;

        this.cursorTrack = new CursorTrackImpl (this, this.host, this.valueChanger, this.bwCursorTrack, this.rootTrackGroup, this.sceneBank, (ApplicationImpl) this.application, numSends, numScenes, numParamPages, numParams);

        final MasterTrack master = controllerHost.createMasterTrack (0);
        this.masterTrack = new MasterTrackImpl (this.host, this.valueChanger, master, this.bwCursorTrack, this.rootTrackGroup, (ApplicationImpl) this.application, this.sceneBank);

        this.trackBank = new TrackBankImpl (this.host, (ApplicationImpl) this.application, this.valueChanger, tb, (CursorTrackImpl) this.cursorTrack, this.rootTrackGroup, numTracks, numScenes, numSends);

        // Optional device banks for each track of the main track bank
        final int numDevicesPerTrack = this.modelSetup.getNumDevicesPerTrack ();
        if (numDevicesPerTrack > 0)
        {
            this.trackDeviceBanks = new IDeviceBank [numTracks];
            for (int i = 0; i < numTracks; i++)
            {
                final DeviceBank bwDeviceBank = tb.getItemAt (i).createDeviceBank (numDevicesPerTrack);
                this.trackDeviceBanks[i] = new DeviceBankImpl (this.host, this.valueChanger, null, bwDeviceBank, numDevicesPerTrack);
                this.trackDevices.put (this.trackBank.getItem (i), new TrackDevices (tb.getItemAt (i), bwDeviceBank, this.trackDeviceBanks[i]));
            }
        }

        final int numFxTracks = this.modelSetup.getNumFxTracks ();
        final TrackBank effectTrackBank = controllerHost.createEffectTrackBank (numFxTracks, numSends, numScenes);
        this.effectTrackBank = new EffectTrackBankImpl (this.host, this.valueChanger, effectTrackBank, (CursorTrackImpl) this.cursorTrack, this.rootTrackGroup, (ApplicationImpl) this.application, numFxTracks, numScenes, numSends, numParamPages, numParams, this.trackBank);

        if (modelSetup.wantsClipLauncherNavigator ())
            this.clipLauncherNavigator = new ClipLauncherNavigatorImpl (controllerHost, this);

        // ----------------------------------------------------------------
        // Create devices

        if (this.modelSetup.wantsFocusedParameter ())
        {
            final LastClickedParameter lcp = this.controllerHost.createLastClickedParameter ("LastHoveredParam", "Last hovered");
            this.focusedParameter = new FocusedParameterImpl (this.valueChanger, lcp.parameter ());
        }

        final int numDevicesInBank = this.modelSetup.getNumDevicesInBank ();
        final int numDeviceLayers = this.modelSetup.getNumDeviceLayers ();
        final int numDrumPadLayers = this.modelSetup.getNumDrumPadLayers ();

        // Cursor device
        final PinnableCursorDevice mainCursorDevice = this.bwCursorTrack.createCursorDevice ("CURSOR_DEVICE", "Cursor device", numSends, CursorDeviceFollowMode.FOLLOW_SELECTION);
        this.cursorDevice = new CursorDeviceImpl (this.host, this.valueChanger, mainCursorDevice, modelSetup);

        // Drum Machine
        if (modelSetup.wantsMainDrumDevice ())
        {
            final DeviceMatcher drumMachineDeviceMatcher = controllerHost.createBitwigDeviceMatcher (INSTRUMENT_DRUM_MACHINE);
            final DeviceBank drumDeviceBank = this.bwCursorTrack.createDeviceBank (1);
            drumDeviceBank.setDeviceMatcher (drumMachineDeviceMatcher);
            final Device drumMachineDevice = drumDeviceBank.getItemAt (0);
            this.drumDevice = new DrumDeviceImpl (this.host, this.valueChanger, drumMachineDevice, numSends, numParamPages, numParams, numDevicesInBank, numDeviceLayers, numDrumPadLayers);

            // Additional drum machines with different drum pad page sizes
            final int [] additionalDrumDevicePageSizes = modelSetup.wantsAdditionalDrumDevices ();
            for (final int pageSize: additionalDrumDevicePageSizes)
            {
                final DrumDeviceImpl addDrumDevice = new DrumDeviceImpl (this.host, this.valueChanger, drumMachineDevice, numSends, 0, 0, -1, pageSize, pageSize);
                this.additionalDrumDevices.put (Integer.valueOf (pageSize), addDrumDevice);
            }
        }

        for (final DeviceID deviceID: modelSetup.getDeviceIDs ())
        {
            final ISpecificDevice specificDevice;
            switch (deviceID)
            {
                case FIRST_INSTRUMENT:
                    final Device instrumentDevice = this.createDevice (controllerHost.createInstrumentMatcher ());
                    specificDevice = new SpecificDeviceImpl (this.host, this.valueChanger, instrumentDevice, modelSetup);
                    if (modelSetup.wantsCursorLayer ())
                    {
                        final CursorDeviceLayer cursorDeviceLayer = instrumentDevice.createCursorLayer ();
                        this.cursorLayer = new CursorLayerImpl (this.host, this.valueChanger, specificDevice.getLayerBank (), cursorDeviceLayer, this.cursorDevice, numParamPages, numParams, numDevicesInBank);
                    }
                    break;

                case EQ:
                    final Device eqDevice = this.createDevice (controllerHost.createBitwigDeviceMatcher (UUID.fromString ("e4815188-ba6f-4d14-bcfc-2dcb8f778ccb")));
                    specificDevice = new EqualizerDeviceImpl (this.host, this.valueChanger, eqDevice, numParamPages, numParams);
                    break;

                case NI_KOMPLETE:
                    final DeviceMatcher vst2DeviceMatcher = controllerHost.createVST2DeviceMatcher (KompleteDevice.VST2_KOMPLETE_ID);
                    final DeviceMatcher vst3DeviceMatcher = controllerHost.createVST3DeviceMatcher (KompleteDevice.VST3_KOMPLETE_ID);
                    final DeviceMatcher vst3Kontakt7DeviceMatcher = controllerHost.createVST3DeviceMatcher (KompleteDevice.VST3_KONTAKT_7_ID);
                    final DeviceMatcher vst3Kontakt8DeviceMatcher = controllerHost.createVST3DeviceMatcher (KompleteDevice.VST3_KONTAKT_8_ID);
                    final DeviceMatcher vst3Maschine3DeviceMatcher = controllerHost.createVST3DeviceMatcher (KompleteDevice.VST3_MASCHINE_3_ID);
                    final Device kompleteDevice = this.createDevice (controllerHost.createOrDeviceMatcher (vst2DeviceMatcher, vst3DeviceMatcher, vst3Kontakt7DeviceMatcher, vst3Kontakt8DeviceMatcher, vst3Maschine3DeviceMatcher));
                    specificDevice = new KompleteDevice (this.host, this.valueChanger, kompleteDevice);
                    break;

                default:
                    // Impossible to reach
                    throw new FrameworkException ("Unknown device ID.");
            }

            this.specificDevices.put (deviceID, specificDevice);
        }

        final int numResults = this.modelSetup.getNumResults ();
        if (numResults > 0)
            this.browser = new BrowserImpl (this.host, controllerHost.createPopupBrowser (), this.bwCursorTrack, mainCursorDevice, this.modelSetup.getNumFilterColumnEntries (), numResults);

        this.masterTrackEqualsValue = mainCursorDevice.channel ().createEqualsValue (master);
        this.masterTrackEqualsValue.markInterested ();

        this.currentTrackBank = this.trackBank;

        controllerHost.scheduleTask (this::flushWorkaround, 4000);
    }


    /**
     * Create a device bank with the given matcher which contains exactly one device.
     *
     * @param deviceMatcher The device matcher to apply
     * @return The device
     */
    private Device createDevice (final DeviceMatcher deviceMatcher)
    {
        final DeviceBank deviceBank = this.bwCursorTrack.createDeviceBank (1);
        deviceBank.setDeviceMatcher (deviceMatcher);
        return deviceBank.getItemAt (0);
    }


    /**
     * Workaround for flush only happening if state changes since Bitwig 3.1 (which is intended and
     * not a bug).
     */
    private void flushWorkaround ()
    {
        // There are enough flushes happening if play-back is active
        if (!this.getTransport ().isPlaying ())
            this.controllerHost.requestFlush ();
        this.controllerHost.scheduleTask (this::flushWorkaround, 100);
    }


    /** {@inheritDoc} */
    @Override
    public boolean isCursorDeviceOnMasterTrack ()
    {
        return this.masterTrackEqualsValue.get ();
    }


    /** {@inheritDoc} */
    @Override
    public ISceneBank getSceneBank (final int numScenes)
    {
        return this.sceneBanks.computeIfAbsent (Integer.valueOf (numScenes), key -> {
            final TrackBank tb = this.controllerHost.createMainTrackBank (1, this.modelSetup.getNumSends (), numScenes);
            tb.followCursorTrack (this.bwCursorTrack);
            return new TrackBankImpl (this.host, (ApplicationImpl) this.application, this.valueChanger, tb, (CursorTrackImpl) this.cursorTrack, this.rootTrackGroup, 1, numScenes, 0).getSceneBank ();
        });
    }


    /** {@inheritDoc} */
    @Override
    public ITrackBank getAdditionalTrackBank (final int numTracks, final int numSends)
    {
        if (numSends <= 0)
            return this.getAdditionalTrackBank (numTracks);

        return this.additionalSendBanks.computeIfAbsent (Integer.valueOf (numTracks * 1000 + numSends), key -> {

            // Only 1 scene but the sends of each track (send matrix)
            final TrackBank tb;
            if (this.modelSetup.hasFlatTrackList ())
            {
                if (this.modelSetup.hasFullFlatTrackList ())
                    tb = this.controllerHost.createTrackBank (numTracks, numSends, 1, true);
                else
                    tb = this.controllerHost.createMainTrackBank (numTracks, numSends, 1);
                tb.followCursorTrack (this.bwCursorTrack);
            }
            else
                tb = this.bwCursorTrack.createSiblingsTrackBank (numTracks, numSends, 1, false, false);

            return new TrackBankImpl (this.host, (ApplicationImpl) this.application, this.valueChanger, tb, (CursorTrackImpl) this.cursorTrack, this.rootTrackGroup, numTracks, 1, numSends);
        });
    }


    /** {@inheritDoc} */
    @Override
    public ITrackBank getAdditionalTrackBank (final int numTracks)
    {
        return this.additionalTrackBanks.computeIfAbsent (Integer.valueOf (numTracks), key -> {

            // Only 1 scene and no sends to keep the overhead low
            final TrackBank tb;
            if (this.modelSetup.hasFlatTrackList ())
            {
                if (this.modelSetup.hasFullFlatTrackList ())
                    tb = this.controllerHost.createTrackBank (numTracks, 0, 1, true);
                else
                    tb = this.controllerHost.createMainTrackBank (numTracks, 0, 1);
                tb.followCursorTrack (this.bwCursorTrack);
            }
            else
                tb = this.bwCursorTrack.createSiblingsTrackBank (numTracks, 0, 1, false, false);

            final TrackBankImpl additionalBank = new TrackBankImpl (this.host, (ApplicationImpl) this.application, this.valueChanger, tb, (CursorTrackImpl) this.cursorTrack, this.rootTrackGroup, numTracks, 1, 0);

            // Optional device banks for the first tracks of the bank (e.g. for the plugin view of
            // 32 tracks)
            final int numDevicesPerTrack = this.modelSetup.getNumDevicesPerTrack ();
            if (numDevicesPerTrack > 0)
            {
                final int numDeviceTracks = Math.min (numTracks, NUM_ADDITIONAL_DEVICE_TRACKS);
                for (int i = 0; i < numDeviceTracks; i++)
                {
                    final DeviceBank bwDeviceBank = tb.getItemAt (i).createDeviceBank (numDevicesPerTrack);
                    final IDeviceBank deviceBank = new DeviceBankImpl (this.host, this.valueChanger, null, bwDeviceBank, numDevicesPerTrack);
                    this.trackDevices.put (additionalBank.getItem (i), new TrackDevices (tb.getItemAt (i), bwDeviceBank, deviceBank));
                }
            }

            return additionalBank;
        });
    }


    /** {@inheritDoc} */
    @Override
    public IDeviceBank getTrackDeviceBank (final int trackIndex)
    {
        return trackIndex >= 0 && trackIndex < this.trackDeviceBanks.length ? this.trackDeviceBanks[trackIndex] : null;
    }


    /** {@inheritDoc} */
    @Override
    public IDeviceBank getTrackDeviceBank (final ITrack track)
    {
        final TrackDevices devices = this.trackDevices.get (track);
        return devices == null ? null : devices.deviceBank ();
    }


    /** {@inheritDoc} */
    @Override
    public boolean editDeviceChain (final DeviceChainOperation operation, final int sourceTrackIndex, final int sourcePosition, final int destinationTrackIndex, final int destinationPosition)
    {
        final int pageSize = this.trackBank.getPageSize ();
        if (sourceTrackIndex < 0 || sourceTrackIndex >= pageSize || destinationTrackIndex < 0 || destinationTrackIndex >= pageSize)
            return false;
        return this.editDeviceChain (operation, this.trackBank.getItem (sourceTrackIndex), sourcePosition, this.trackBank.getItem (destinationTrackIndex), destinationPosition);
    }


    /** {@inheritDoc} */
    @Override
    public boolean editDeviceChain (final DeviceChainOperation operation, final ITrack sourceTrack, final int sourcePosition, final ITrack destinationTrack, final int destinationPosition)
    {
        final TrackDevices sourceDevices = this.trackDevices.get (sourceTrack);
        final TrackDevices destinationDevices = this.trackDevices.get (destinationTrack);
        if (sourceDevices == null || destinationDevices == null)
            return false;

        // Note: The devices of a bank are slots which might point to a different device after an
        // operation was executed. Therefore, the operations which need 2 steps are designed to
        // work no matter if the device references are resolved before or after the first step
        final Device source = this.getTrackDevice (sourceDevices, sourcePosition);
        if (source == null)
            return false;
        final Device destination = destinationPosition < 0 ? null : this.getTrackDevice (destinationDevices, destinationPosition);
        // The destination is not on the current page (should not happen)
        if (destinationPosition >= 0 && destination == null)
            return false;
        final Track destinationBwTrack = destinationDevices.track ();

        switch (operation)
        {
            case COPY:
                (destination == null ? destinationBwTrack.endOfDeviceChainInsertionPoint () : destination.beforeDeviceInsertionPoint ()).copyDevices (source);
                return true;

            case MOVE:
                (destination == null ? destinationBwTrack.endOfDeviceChainInsertionPoint () : destination.beforeDeviceInsertionPoint ()).moveDevices (source);
                return true;

            case REPLACE:
                if (destination == null)
                {
                    destinationBwTrack.endOfDeviceChainInsertionPoint ().copyDevices (source);
                    return true;
                }
                // Insert the copy after the destination, which keeps the position of the
                // destination, then delete it
                destination.afterDeviceInsertionPoint ().copyDevices (source);
                destination.deleteObject ();
                return true;

            case SWAP:
                if (destination == null)
                    return false;
                return this.swapDevices (sourceDevices, sourcePosition, destinationDevices, destinationPosition);

            default:
                return false;
        }
    }


    private boolean swapDevices (final TrackDevices sourceDevices, final int sourcePosition, final TrackDevices destinationDevices, final int destinationPosition)
    {
        if (sourceDevices == destinationDevices)
        {
            if (sourcePosition == destinationPosition)
                return true;
            final int lowPosition = Math.min (sourcePosition, destinationPosition);
            final int highPosition = Math.max (sourcePosition, destinationPosition);
            final Device low = this.getTrackDevice (sourceDevices, lowPosition);
            final Device high = this.getTrackDevice (sourceDevices, highPosition);
            final InsertionPoint lowInsertionPoint = this.getInsertionPointAfter (sourceDevices, lowPosition - 1);
            if (low == null || high == null || lowInsertionPoint == null)
                return false;
            // 1. Move the low device directly before the high device, which keeps the position of
            // the high device and all devices before the low device
            high.beforeDeviceInsertionPoint ().moveDevices (low);
            // 2. Move the high device to the former position of the low device
            lowInsertionPoint.moveDevices (high);
            return true;
        }

        final Device source = this.getTrackDevice (sourceDevices, sourcePosition);
        final Device destination = this.getTrackDevice (destinationDevices, destinationPosition);
        final InsertionPoint destinationInsertionPoint = this.getInsertionPointAfter (destinationDevices, destinationPosition - 1);
        if (source == null || destination == null || destinationInsertionPoint == null)
            return false;
        // 1. Move the destination device after the source device, keeps the position of the source
        source.afterDeviceInsertionPoint ().moveDevices (destination);
        // 2. Move the source device to the former position of the destination device
        destinationInsertionPoint.moveDevices (source);
        return true;
    }


    /**
     * Get the insertion point after the device at the given position or the start of the chain.
     *
     * @param devices The devices of the track
     * @param position The position of the device, -1 for the start of the chain
     * @return The insertion point or null if the device is not on the current page of the device
     *         bank of the track
     */
    private InsertionPoint getInsertionPointAfter (final TrackDevices devices, final int position)
    {
        if (position < 0)
            return devices.track ().startOfDeviceChainInsertionPoint ();
        final Device device = this.getTrackDevice (devices, position);
        return device == null ? null : device.afterDeviceInsertionPoint ();
    }


    /**
     * Get the device at the given position in the device chain of a track.
     *
     * @param devices The devices of the track
     * @param position The position of the device in the chain
     * @return The device or null if it is not on the current page of the device bank of the track
     */
    private Device getTrackDevice (final TrackDevices devices, final int position)
    {
        final DeviceBank deviceBank = devices.bwDeviceBank ();
        final int index = position - deviceBank.scrollPosition ().get ();
        if (position < 0 || index < 0 || index >= this.modelSetup.getNumDevicesPerTrack () || position >= deviceBank.itemCount ().get ())
            return null;
        return deviceBank.getItemAt (index);
    }


    /** {@inheritDoc} */
    @Override
    public ISlotBank getSlotBank (final int numSlots)
    {
        return this.slotBanks.computeIfAbsent (Integer.valueOf (numSlots), key -> {

            final CursorTrack ct = this.controllerHost.createCursorTrack ("CursorTrackID" + numSlots, "Cursor Track for " + numSlots + "Slots", 0, numSlots, true);
            final ICursorTrack cursorTrack = new CursorTrackImpl (this, this.host, this.valueChanger, ct, this.rootTrackGroup, this.sceneBank, (ApplicationImpl) this.application, 0, numSlots, 0, 0);
            return new SlotBankImpl (this.host, this.valueChanger, cursorTrack, this.sceneBank, ct.clipLauncherSlotBank (), numSlots);

        });
    }


    /** {@inheritDoc} */
    @Override
    public INoteClip getNoteClip (final int cols, final int rows)
    {
        return this.cursorClips.computeIfAbsent (cols + "-" + rows, k -> new CursorClipImpl (this.host, this.bwCursorTrack, this.valueChanger, cols, rows));
    }


    /** {@inheritDoc} */
    @Override
    public void createNoteClip (final ITrack track, final ISlot slot, final int lengthInBeats, final boolean overdub)
    {
        track.createClip (slot.getIndex (), lengthInBeats);
        slot.select ();
        slot.launch (true, false);
        if (overdub)
            this.transport.setLauncherOverdub (true);
    }


    /** {@inheritDoc} */
    @Override
    public void recordNoteClip (final ITrack track, final ISlot slot)
    {
        if (!slot.isRecording ())
            slot.startRecording ();
        slot.launch (true, false);
    }


    /** {@inheritDoc} */
    @Override
    public INoteClip getCursorClip ()
    {
        if (this.cursorClips.isEmpty ())
            throw new FrameworkException ("No cursor clip created!");
        return this.cursorClips.values ().iterator ().next ();
    }


    /** {@inheritDoc} */
    @Override
    public void ensureClip ()
    {
        this.getNoteClip (0, 0);
    }


    /** {@inheritDoc} */
    @Override
    public void cleanup ()
    {
        // Nothing to do
    }


    /** {@inheritDoc} */
    @Override
    public Optional<IFocusedParameter> getFocusedParameter ()
    {
        if (this.focusedParameter == null)
            throw new FrameworkException ("No focused parameter created!");
        return Optional.of (this.focusedParameter);
    }
}